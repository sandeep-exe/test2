import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import models.Board;
import models.Dice;
import models.Jumper;
import models.Player;

public class Game {

	public static void main(String[] args) throws Exception {
		Queue<Player> queue = new LinkedList<>();

		for (int i = 0; i < 5; i++) {
			String playerName = String.format("Player-%s", i + 1);
			var player = new Player(playerName, 0);
			queue.add(player);
		}

		List<Jumper> snakes = Arrays.asList(new Jumper(27, 1), new Jumper(21, 9), new Jumper(17, 4), new Jumper(19, 7));
		List<Jumper> ladders = Arrays.asList(new Jumper(11, 26), new Jumper(3, 22), new Jumper(20, 29),
				new Jumper(5, 8));
		int boardSize = 30;

		Board board = new Board(boardSize, snakes, ladders);

		while (queue.size() > 1) {
			
			var player = queue.poll();
//			System.out.print(player.getPlayerName());
			var diceValue = Dice.getNumber();
//			System.out.print(" Curr:" + player.getPosition());
//			System.out.print(" Dice:" + diceValue);
			int playerNextPos = player.getPosition() + diceValue;

			if (board.getSnakes().getSnakes().containsKey(playerNextPos)) {
//				System.out.print(" Bite Snake:");
				playerNextPos = board.getSnakes().getSnakes().get(playerNextPos);
			}

			if (board.getLadders().getLadders().containsKey(playerNextPos)) {
//				System.out.print(" Clinb Ladder:");
				playerNextPos = board.getLadders().getLadders().get(playerNextPos);
			}

			if (playerNextPos == boardSize) {
				System.out.println(player.getPlayerName() + " wins!");
			} else if (playerNextPos < boardSize) {
				player.setPosition(playerNextPos);
//				System.out.print( " " + player.getPosition());
				queue.add(player);
			} else {
				queue.add(player);
			}
//			System.out.println();
		}

	}

}
