package models;

import java.util.List;

import lombok.Getter;

@Getter
public class Board {
	private Snakes snakes;
	private Ladders ladders;
	private int size;

	public Board(int size, List<Jumper> incommingSnakes, List<Jumper> incommingLadder) throws Exception {
		this.snakes = new Snakes();
		this.ladders = new Ladders();
		this.size = size;
		this.setup(incommingSnakes, incommingLadder);
	}

	private void setup(List<Jumper> incommingSnakes, List<Jumper> incommingLadder) throws Exception {
		for (Jumper snake : incommingSnakes) {
			this.checkJumperOutofBound(snake);
			this.snakes.addSnakes(snake.getStart(), snake.getEnd());
		}

		for (Jumper ladder : incommingLadder) {
			this.checkJumperOutofBound(ladder);
			this.ladders.addSnakes(ladder.getStart(), ladder.getEnd());
		}
	}

	private void checkJumperOutofBound(Jumper jumper) throws Exception {
		int start = jumper.getStart();
		int end = jumper.getEnd();
		if (!(1 <= start && end <= this.size)) {
			throw new Exception(String.format("Start=%s and End=%s out of bound", start, end));
		}
	}
}
