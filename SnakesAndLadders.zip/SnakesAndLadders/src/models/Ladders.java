package models;

import java.util.HashMap;

import lombok.Getter;

@Getter
public class Ladders {
	private HashMap<Integer, Integer> ladders;

	public Ladders() {
		this.ladders = new HashMap<>();
	}

	public void addSnakes(int startPos, int endPos) throws Exception {
		if (startPos > endPos) {
			throw new Exception("startPos cannot be greater than endPos");
		}

		this.ladders.put(startPos, endPos);
	}
}
