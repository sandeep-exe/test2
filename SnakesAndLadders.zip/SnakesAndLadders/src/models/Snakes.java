package models;

import java.util.HashMap;

import lombok.Getter;

@Getter
public class Snakes {
	private HashMap<Integer, Integer> snakes;
	
	public Snakes() {
		this.snakes = new HashMap<>();
	}
	
	public void addSnakes(int headPos, int tailPos) throws Exception {
		if(headPos < tailPos) {
			throw new Exception("tailPost cannot be greater than headPos");
		}
		
		this.snakes.put(headPos, tailPos);
	}
	
}
