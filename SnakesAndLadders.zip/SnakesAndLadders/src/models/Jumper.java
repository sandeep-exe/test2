package models;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor @Getter
public class Jumper {
	private int start;
	private int end;
}
